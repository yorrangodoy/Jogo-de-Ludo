import sys
import random
import pygame
from pygame.locals import QUIT, MOUSEBUTTONDOWN

# -- Constantes -------------------------------------------------------------
CELL_SIZE = 40
GRID_SIZE = 15
BOARD_PIXELS = CELL_SIZE * GRID_SIZE
UI_HEIGHT = 100
WINDOW_WIDTH = BOARD_PIXELS
WINDOW_HEIGHT = BOARD_PIXELS + UI_HEIGHT
FPS = 60

# Cores RGB
BLACK   = (  0,   0,   0)
GRAY    = (100, 100, 100)
WHITE   = (255, 255, 255)
GREEN   = (  0, 200,   0)
YELLOW  = (200, 200,   0)
RED     = (200,   0,   0)
BLUE    = (  0,   0, 200)
COLORS = {'green': GREEN, 'yellow': YELLOW, 'red': RED, 'blue': BLUE}
NAMES_PORTUGUES = {'green': 'Verde', 'yellow': 'Amarelo', 'red': 'Vermelho', 'blue': 'Azul'}

# ---------------------------------------------------------------------------
# Estruturas de dados conforme algoritmos solicitados:
#
# 1. LISTA:
#    - PATH_CELLS: lista de tuplas que representam as coordenadas do caminho principal.
#    - FINAL_CELLS e BASE_CELLS: listas de tuplas para caminhos finais e bases.
#    - self.players: lista que armazena instâncias de Player (um para cada cor selecionada).
#    - self.pieces em cada Player: lista que armazena instâncias de Piece (até 4 peças por jogador).
#
# 2. FILA (conceitual):
#    - A ordem de turnos é gerenciada como uma fila circular. O índice self.current aponta para o jogador atual,
#      e ao final de um turno, incrementamos self.current para passar à próxima pessoa na fila.
#    - Isso emula o comportamento de uma FILA (FIFO) para passagem de turno.
#
# 3. PILHA (conceitual):
#    - Cada animação de movimento passo a passo em animate_move "empilha" estados intermediários de peça,
#      renderizados um a um. Embora não haja operação explícita de desempilhar (pop), esse laço sequencial
#      de estados funciona como uma PILHA de quadro a quadro para animação.
#    - Em um cenário com função de "undo", poderíamos usar uma PILHA para armazenar estados anteriores das peças.
# ---------------------------------------------------------------------------

# Geometria do caminho (coordenadas na grade)
PATH_CELLS = [
    (6, 0), (6, 1), (6, 2), (6, 3), (6, 4), (6, 5),
    (5, 6), (4, 6), (3, 6), (2, 6), (1, 6), (0, 6),
    (0, 7), (0, 8), (1, 8), (2, 8), (3, 8), (4, 8), (5, 8),
    (6, 9), (6,10), (6,11), (6,12), (6,13), (6,14),
    (7,14), (8,14), (8,13), (8,12), (8,11), (8,10), (8, 9),
    (9, 8), (10,8), (11,8), (12,8), (13,8), (14,8),
    (14,7), (14,6), (13,6), (12,6), (11,6), (10,6), (9, 6),
    (8, 5), (8, 4), (8, 3), (8, 2), (8, 1), (8, 0), (7, 0)
]
# LISTA: armazena as 52 posições do caminho principal do tabuleiro

START_OFFSET = {'green': 0, 'yellow': 13, 'red': 26, 'blue': 39}
SAFE_INDICES = {0, 8, 13, 21, 26, 34, 39, 47}

FINAL_CELLS = {
    'green': [(7,1),(7,2),(7,3),(7,4),(7,5),(7,6)],     # LISTA: caminho final Verde
    'yellow':[(13,7),(12,7),(11,7),(10,7),(9,7),(8,7)],  # LISTA: caminho final Amarelo
    'red':   [(7,13),(7,12),(7,11),(7,10),(7,9),(7,8)],  # LISTA: caminho final Vermelho
    'blue':  [(1,7),(2,7),(3,7),(4,7),(5,7),(6,7)]       # LISTA: caminho final Azul
}
HOME_CELL = (7,7)

BASE_CELLS = {
    'green': [(1,1),(1,3),(3,1),(3,3)],     # LISTA: posições de base Verde
    'yellow':[(11,1),(11,3),(13,1),(13,3)], # LISTA: posições de base Amarelo
    'red':   [(11,11),(11,13),(13,11),(13,13)], # LISTA: posições de base Vermelho
    'blue':  [(1,11),(1,13),(3,11),(3,13)]  # LISTA: posições de base Azul
}


# -- Classes ----------------------------------------------------------------
class Piece:
    """Representa um peão de Ludo."""
    def __init__(self, color, idx):
        self.color = color
        self.idx = idx
        self.step = -1      # -1 = base, 0-51 = caminho, 52-57 = final, 58 = home
        self.anim_pos = None

    def at_base(self):
        return self.step == -1

    def at_home(self):
        return self.step == 58

    def can_move(self, roll):
        if self.at_home():
            return False
        if self.at_base():
            return roll == 6
        return (self.step + roll) <= 58

    def move(self, roll):
        if self.at_base() and roll == 6:
            self.step = 0
        elif self.step >= 0:
            self.step += roll

    def get_grid_pos(self):
        if self.step == -1:
            # LISTA: retorna posição da base a partir de BASE_CELLS
            return BASE_CELLS[self.color][self.idx]
        if 0 <= self.step <= 51:
            abs_i = (START_OFFSET[self.color] + self.step) % len(PATH_CELLS)
            # LISTA: retorna posição no caminho principal a partir de PATH_CELLS
            return PATH_CELLS[abs_i]
        if 52 <= self.step <= 57:
            # LISTA: retorna posição no caminho final a partir de FINAL_CELLS
            return FINAL_CELLS[self.color][self.step - 52]
        return HOME_CELL


class Dice:
    """Representa o dado, com animação ao rolar."""
    def __init__(self):
        self.value = None
        self.rolling = False
        self.roll_frames = 0

    def roll(self):
        self.rolling = True
        self.roll_frames = 15
        self.value = None

    def update(self):
        if self.rolling:
            if self.roll_frames > 0:
                self.value = random.randint(1, 6)
                self.roll_frames -= 1
            else:
                self.rolling = False

    def draw(self, surf):
        size = 80
        margin = 10
        x = WINDOW_WIDTH - size - margin
        y = BOARD_PIXELS + (UI_HEIGHT - size) // 2
        pygame.draw.rect(surf, WHITE, (x, y, size, size), border_radius=8)
        if self.value:
            pip = size // 8
            coords = []
            mid = (x + size//2, y + size//2)
            offs = size // 4
            if self.value in (1, 3, 5):
                coords.append(mid)
            if self.value in (2, 3, 4, 5, 6):
                coords += [(x + offs, y + offs), (x + size - offs, y + size - offs)]
            if self.value in (4, 5, 6):
                coords += [(x + offs, y + size - offs), (x + size - offs, y + offs)]
            if self.value == 6:
                coords += [(x + offs, y + size//2), (x + size - offs, y + size//2)]
            for cx, cy in coords:
                pygame.draw.circle(surf, BLACK, (cx, cy), pip)


class Player:
    """Representa um jogador, que possui até 4 peças (LISTA)."""
    def __init__(self, color):
        self.color = color
        self.pieces = [Piece(color, i) for i in range(4)]  # LISTA: armazena as 4 peças

    def has_moves(self, roll):
        # Itera sobre a LISTA de peças para verificar se alguma pode se mover
        return any(p.can_move(roll) for p in self.pieces)

    def all_home(self):
        # Verifica se todas as peças estão em casa (HOME)
        return all(p.at_home() for p in self.pieces)


class Board:
    """Responsável por desenhar o tabuleiro e suas áreas (LISTAS de células)."""
    def draw(self, surf):
        surf.fill(BLACK)
        pygame.draw.rect(surf, GRAY, (0, 0, BOARD_PIXELS, BOARD_PIXELS), 4)

        # Desenha bases (LISTA BASE_CELLS)
        for color, cells in BASE_CELLS.items():
            for c, r in cells:
                pygame.draw.rect(surf, COLORS[color], (c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE))
                pygame.draw.rect(surf, WHITE, (c * CELL_SIZE + 5, r * CELL_SIZE + 5, CELL_SIZE - 10, CELL_SIZE - 10), 2)

        # Desenha caminho principal (LISTA PATH_CELLS)
        for idx, (c, r) in enumerate(PATH_CELLS):
            pygame.draw.rect(surf, GRAY, (c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE))
            if idx in SAFE_INDICES:
                pygame.draw.circle(
                    surf,
                    WHITE,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    5
                )

        # Desenha caminho final (LISTA FINAL_CELLS)
        for color, cells in FINAL_CELLS.items():
            for c, r in cells:
                pygame.draw.rect(surf, COLORS[color], (c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE))

        # Desenha a célula HOME (centro)
        cx, cy = HOME_CELL
        pygame.draw.rect(surf, WHITE, (cx * CELL_SIZE, cy * CELL_SIZE, CELL_SIZE, CELL_SIZE))


class Game:
    """Classe principal que gerencia o fluxo do jogo."""
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Ludo Clash")
        self.clock = pygame.time.Clock()
        self.board = Board()
        self.dice = Dice()
        self.font = pygame.font.SysFont(None, 36)
        self.small_font = pygame.font.SysFont(None, 28)
        self.current = 0            # Índice do jogador na FILA de turnos
        self.roll_occurred = False
        self.move_phase = False
        self.selected_piece = None
        self.players = []           # LISTA que armazenará as instâncias de Player
        self.show_menu()            # Exibe o menu antes de iniciar o loop principal

    def show_menu(self):
        """Exibe menu para seleção de 2 ou 4 jogadores (LISTA de botões)."""
        btn_width = 250
        btn_height = 60
        spacing = 20
        total_height = btn_height * 2 + spacing
        start_y = (WINDOW_HEIGHT - total_height) // 2

        # Retângulos dos botões (LISTA: [btn2, btn4])
        btn2 = pygame.Rect((WINDOW_WIDTH - btn_width) // 2, start_y, btn_width, btn_height)
        btn4 = pygame.Rect((WINDOW_WIDTH - btn_width) // 2, start_y + btn_height + spacing, btn_width, btn_height)

        while True:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == MOUSEBUTTONDOWN:
                    x, y = event.pos
                    if btn2.collidepoint(x, y):
                        self.init_players(2)
                        return
                    if btn4.collidepoint(x, y):
                        self.init_players(4)
                        return

            # Desenha fundo de menu
            self.screen.fill(BLACK)

            # Título "Ludo Clash"
            title_surf = self.font.render("Ludo Clash", True, WHITE)
            self.screen.blit(
                title_surf,
                (WINDOW_WIDTH // 2 - title_surf.get_width() // 2, start_y - 100)
            )

            # Subtítulo "A3 - Unisul" abaixo do título
            subtitle_surf = self.small_font.render("A3 - Unisul", True, WHITE)
            self.screen.blit(
                subtitle_surf,
                (WINDOW_WIDTH // 2 - subtitle_surf.get_width() // 2, start_y - 60)
            )

            # Botão "2 Jogadores"
            pygame.draw.rect(self.screen, GRAY, btn2, border_radius=8)
            txt2 = self.small_font.render("2 Jogadores", True, BLACK)
            self.screen.blit(
                txt2,
                (btn2.x + btn_width // 2 - txt2.get_width() // 2, btn2.y + btn_height // 2 - txt2.get_height() // 2)
            )

            # Botão "4 Jogadores"
            pygame.draw.rect(self.screen, GRAY, btn4, border_radius=8)
            txt4 = self.small_font.render("4 Jogadores", True, BLACK)
            self.screen.blit(
                txt4,
                (btn4.x + btn_width // 2 - txt4.get_width() // 2, btn4.y + btn_height // 2 - txt4.get_height() // 2)
            )

            pygame.display.flip()

    def init_players(self, num):
        """
        Inicializa jogadores com base na escolha do menu:
        - 2 jogadores: cores 'green' e 'red'
        - 4 jogadores: cores 'green', 'yellow', 'red', 'blue'
        (LISTA de cores selecionadas)
        """
        if num == 2:
            selected = ['green', 'red']
        else:
            selected = ['green', 'yellow', 'red', 'blue']
        # LISTA: cria instâncias de Player para cada cor selecionada
        self.players = [Player(c) for c in selected]

    def loop(self):
        """Loop principal do jogo, onde atualizamos animações e aguardamos cliques."""
        while True:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == MOUSEBUTTONDOWN:
                    self.handle_click(event.pos)

            # Atualiza animação do dado
            self.dice.update()

            # FILA (conceitual): verifica se o dado terminou de rolar e entra em fase de movimento ou passa a vez
            if self.roll_occurred and not self.dice.rolling and not self.move_phase:
                if self.players[self.current].has_moves(self.dice.value):
                    self.move_phase = True
                else:
                    # Sem movimentos possíveis: avança para o próximo índice na lista de jogadores (FIFO)
                    self.current = (self.current + 1) % len(self.players)
                    self.roll_occurred = False
                    self.move_phase = False

            self.draw()
            pygame.display.flip()

    def handle_click(self, pos):
        """Trata evento de clique: ou rolar o dado ou selecionar peça para mover."""
        x, y = pos
        size = 80
        margin = 10
        dx = WINDOW_WIDTH - size - margin
        dy = BOARD_PIXELS + (UI_HEIGHT - size) // 2

        # Clique no dado
        if dx <= x <= dx + size and dy <= y <= dy + size:
            self.try_roll()

        # Caso esteja na fase de movimento e sem peça selecionada, tenta escolher uma peça
        elif self.move_phase and not self.selected_piece:
            self.try_select_piece(pos)

    def try_roll(self):
        """Inicia animação de rolar o dado, se ainda não rolou nesta rodada."""
        if not self.roll_occurred and not self.dice.rolling:
            self.dice.roll()
            self.roll_occurred = True
            self.move_phase = False
            self.selected_piece = None

    def try_select_piece(self, pos):
        """
        Tenta selecionar um dos peões do jogador atual:
        - Itera sobre a LISTA de peças (self.players[self.current].pieces)
        - Verifica colisão circular com clique
        - Se a peça puder mover, chama animate_move
        """
        for piece in self.players[self.current].pieces:
            col, row = piece.get_grid_pos()
            cx = col * CELL_SIZE + CELL_SIZE // 2
            cy = row * CELL_SIZE + CELL_SIZE // 2
            if (pos[0] - cx) ** 2 + (pos[1] - cy) ** 2 <= (CELL_SIZE // 2) ** 2:
                if piece.can_move(self.dice.value):
                    self.selected_piece = piece
                    self.animate_move(piece, self.dice.value)
                break

    def animate_move(self, piece, roll):
        """
        Realiza animação de movimento para a peça selecionada:
        - Calcula old_step e new_step
        - Para cada passo entre old_step+1 e new_step, instancia temporariamente uma peça (PILHA conceitual
          de quadros de animação) e chama smooth_move para renderizar o movimento suave.
        - Após terminar, chama capture e verifica vitória/avanço de turno.
        """
        old_step = piece.step
        piece.move(roll)
        new_step = piece.step

        # PILHA (conceitual): cada iteração adiciona um estado de animação à "pilha" de quadros
        for i in range(old_step + 1, new_step + 1):
            temp = Piece(piece.color, piece.idx)
            temp.step = i
            tx, ty = temp.get_grid_pos()
            target = (tx * CELL_SIZE + CELL_SIZE // 2, ty * CELL_SIZE + CELL_SIZE // 2)
            self.smooth_move(piece, target)

        # Após mover, verifica captura de peças adversárias
        self.capture(piece)

        # Verifica se este jogador venceu
        if self.players[self.current].all_home():
            self.show_winner(self.players[self.current].color)
            return

        # Se não rolou 6 ou se não há mais movimentos possíveis com 6, avança fila de turno
        if self.dice.value != 6 or not self.players[self.current].has_moves(6):
            # FILA (conceitual): move para o próximo jogador na lista
            self.current = (self.current + 1) % len(self.players)

        self.roll_occurred = False
        self.move_phase = False
        self.selected_piece = None

    def smooth_move(self, piece, target):
        """
        Move a peça suavemente de sua posição atual até 'target' em 10 quadros:
        - Se anim_pos não existe, inicializa com posição atual (listagem de coordenadas).
        - Em cada quadro, calcula 'frac' e interpola entre start e target.
        - PILHA (conceitual): quadros intermediários são empilhados na animação.
        """
        if not piece.anim_pos:
            c0, r0 = piece.get_grid_pos()
            piece.anim_pos = (c0 * CELL_SIZE + CELL_SIZE // 2, r0 * CELL_SIZE + CELL_SIZE // 2)

        start = piece.anim_pos
        dx = target[0] - start[0]
        dy = target[1] - start[1]
        frames = 10

        for i in range(frames):
            frac = (i + 1) / frames
            piece.anim_pos = (start[0] + dx * frac, start[1] + dy * frac)
            self.draw()
            pygame.display.flip()
            self.clock.tick(FPS)

        piece.anim_pos = target

    def capture(self, mover):
        """
        Captura peças adversárias:
        - Se a peça mover estiver no caminho principal (0-51) e não em posição SAFE,
          para cada jogador (LISTA self.players) diferente de mover.color, itera as peças
          (LISTA pl.pieces) e, se estiverem na mesma célula, retorna-as à base (step = -1).
        """
        pos = mover.get_grid_pos()
        if 0 <= mover.step <= 51:
            if pos in PATH_CELLS:
                idx = PATH_CELLS.index(pos)
                if idx not in SAFE_INDICES:
                    for pl in self.players:  # percorre FILA de jogadores
                        if pl.color != mover.color:
                            for pc in pl.pieces:  # percorre LISTA de peças
                                if pc.get_grid_pos() == pos:
                                    pc.step = -1
                                    pc.anim_pos = None

    def show_winner(self, color):
        """Exibe mensagem de vitória e encerra o jogo."""
        self.draw()  # desenha estado final
        msg = f"{NAMES_PORTUGUES[color]} venceu!"
        text = self.font.render(msg, True, WHITE)
        self.screen.blit(
            text,
            (WINDOW_WIDTH // 2 - text.get_width() // 2,
             BOARD_PIXELS // 2 - text.get_height() // 2)
        )
        pygame.display.flip()
        pygame.time.wait(3000)
        pygame.quit()
        sys.exit()

    def draw(self):
        """Desenha o tabuleiro, os peões e o dado, além do texto de instruções."""
        # Desenha o tabuleiro e áreas (usa LISTAS PATH_CELLS, BASE_CELLS, FINAL_CELLS)
        self.board.draw(self.screen)

        # Desenha cada peão como círculo
        for pl in self.players:  # percorre FILA de jogadores
            for pc in pl.pieces:  # percorre LISTA de peças
                if pc.anim_pos:
                    x, y = pc.anim_pos
                else:
                    c, r = pc.get_grid_pos()  # obtém posição a partir de LISTA de células
                    x = c * CELL_SIZE + CELL_SIZE // 2
                    y = r * CELL_SIZE + CELL_SIZE // 2
                pygame.draw.circle(
                    self.screen,
                    COLORS[pc.color],
                    (int(x), int(y)),
                    CELL_SIZE // 2 - 5
                )

        # Desenha o dado no canto inferior direito
        self.dice.draw(self.screen)

        # Exibe instruções e status em Português no canto inferior esquerdo
        linha_x = 10
        linha_y = BOARD_PIXELS + 10
        cor_atual = NAMES_PORTUGUES[self.players[self.current].color]
        msg = f"Turno do {cor_atual}. "
        if self.roll_occurred:
            if self.dice.rolling:
                msg += "Jogando o dado..."
            else:
                msg += f"Saiu: {self.dice.value}. Selecione peça."
        else:
            msg += "Clique no dado."
        text = self.small_font.render(msg, True, WHITE)
        self.screen.blit(text, (linha_x, linha_y))


if __name__ == '__main__':
    game = Game()
    game.loop()
